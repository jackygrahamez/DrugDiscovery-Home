#
# $Header: /opt/cvs/python/packages/share1.5/MolKit/introduction.py,v 1.1.1.1 2001/04/03 19:47:52 gillet Exp $
#
# $Id: introduction.py,v 1.1.1.1 2001/04/03 19:47:52 gillet Exp $
#

"""This package contains a number of class to describe molecular entities such as Molecules, Molecular surface"""
